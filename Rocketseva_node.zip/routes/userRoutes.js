const express = require('express');
const router = express.Router();
const userController = require('../controllers/UserController');

// User registration
router.post('/register', userController.registerUser);

// Hospital User registration
router.post('/registerHospitalUser', userController.registerHospitalUser);


// User login
router.post('/login', userController.loginUser);

// Get the total number of users
router.get('/totalUsers', userController.getTotalUsers);


// Add more user-related routes as needed

module.exports = router;


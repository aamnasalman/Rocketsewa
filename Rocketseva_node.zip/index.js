const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const dotenv = require('dotenv'); // For managing environment variables
dotenv.config(); // Load environment variables from a .env file if available

// Create an Express application
const app = express();

// Middleware to parse JSON requests
app.use(bodyParser.json());

// Define routes (import your route files here)
const userRoutes = require('./routes/userRoutes');
const subscriptionRoutes = require('./routes/subscriptionRoutes');
const contentRoutes = require('./routes/contentRoutes');
const analyticsRoutes = require('./routes/analyticsRoutes');

// Use the defined routes
app.use('/users', userRoutes);
app.use('/subscriptions', subscriptionRoutes);
app.use('/content', contentRoutes);
app.use('/analytics', analyticsRoutes);

// Define a default route
app.get('/', (req, res) => {
  res.send('Welcome to the Rocketsewa Platform API');
});

// Define a port for the Express server
const PORT = process.env.PORT || 3000;

// Start the Express server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

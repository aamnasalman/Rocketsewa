const mongoose = require('mongoose');
const dotenv = require('dotenv'); // For managing environment variables
dotenv.config(); // Load environment variables from a .env file if available

// Retrieve the MongoDB connection URL from environment variables
const DB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/rocketsewa';

// Connect to MongoDB
mongoose.connect(DB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  useCreateIndex: true,
});

// Get the default connection
const db = mongoose.connection;

// Handle MongoDB connection events
db.on('error', (error) => {
  console.error(`MongoDB connection error: ${error}`);
});

db.once('open', () => {
  console.log('Connected to MongoDB');
});
